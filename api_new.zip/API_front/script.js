function togglePassword() {
    const passwordInput = document.getElementById("password");
    const eyeIcon = document.getElementById("eyeIcon");
    if (passwordInput.type === "password") {
      passwordInput.type = "text";
      eyeIcon.src = "https://img.icons8.com/ios-filled/50/ffffff/closed-eye.png";
    } else {
      passwordInput.type = "password";
      eyeIcon.src = "https://img.icons8.com/ios-filled/50/ffffff/visible.png";
    }
  }
  
  // LOGIN
  document.getElementById("login-form").addEventListener("submit", async function (e) {
    e.preventDefault();
  
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
  
    const response = await fetch("http://127.0.0.1:8000/api/token/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password })
    });
  
    const data = await response.json();
  
    if (data.access) {
      localStorage.setItem("access_token", data.access);
      console.log(data.access)
      document.getElementById("login-status").innerText = "✅ Login Successful!";
    } else {
      document.getElementById("login-status").innerText = "❌ Login Failed!";
    }
  });
  
  
  
  
  