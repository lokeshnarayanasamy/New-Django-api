from rest_framework.views import APIView
from rest_framework.response import Response
#from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import api_view
from .models import *
from .serializers import *
from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.permissions import IsAuthenticated
import csv
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework import status

class BlogPostView(APIView):
    parser_classes = [MultiPartParser, FormParser]

    permission_classes = [IsAuthenticated]
    


    def get(self,request):

        blog = Post_1.objects.all()

        blog_serializer = BlogPost_serializer(blog,many=True).data

        return Response(blog_serializer)
    

    def post(self, request, *args, **kwargs):
        serializer = BlogPost_serializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=201)
        return Response(serializer.errors, status=400)


class BlogPostViewById(APIView):

    permission_classes = [IsAuthenticated]



    def get(self,request,id):

        post = Post_1.objects.get(id=id)

        blog_serializer = BlogPost_serializer(post,many=False).data

        return Response(blog_serializer)

    def delete(self, request, id):
        post = get_object_or_404(Post_1, id=id)
        AuditLog.objects.create(model_name='Post_1', object_id=id, action='DELETE')
        post.delete()
        return Response({'message': 'Deleted'}, status=status.HTTP_204_NO_CONTENT)

    def put(self, request, pk):
        post = get_object_or_404(Post_1, id=id)
        old_data = post.title + " | " + post.content
        serializer = PostSerializer(post, data=request.data)
        if serializer.is_valid():
            serializer.save()
            AuditLog.objects.create(
                model_name='Post_1',
                object_id=pk,
                action='UPDATE',
                changed_data=old_data
            )
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class AuditLogListView(APIView):
    def get(self, request):
        logs = AuditLog.objects.all().order_by('-timestamp')
        data = [{
            "model": log.model_name,
            "action": log.action,
            "object_id": log.object_id,
            "timestamp": log.timestamp.strftime('%Y-%m-%d %H:%M:%S'),
            "changed_data": log.changed_data
        } for log in logs]
        return Response(data)

class BlogCommentViewById(APIView):

    permission_classes = [IsAuthenticated]


    def get(self,request,id):

        post_id = Post_1.objects.get(id=id)

        comment = Comment_1.objects.filter(post_id=post_id)

        comment_serializer =BlogComment_serializer(comment,many=True).data

        return Response(comment_serializer)
    
    
    def post(self,request,id):
        
        post_id =Post_1.objects.get(id=id)
        print(request.data['content'])
        print()
        data_1 =Comment_1.objects.create(post=post_id,content=request.data['content'],author=request.user)
        data_1.save()
        return Response(f"Your Comment Was Add Successfuly")

    






class ExportPostsCSV(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        # Create the response object with content-type for CSV
        response = HttpResponse(content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="posts.csv"'

        # Create the CSV writer and write the header row
        writer = csv.writer(response)
        writer.writerow(['ID', 'Title', 'Content', 'File'])

        # Loop through the posts and write each row
        posts = Post.objects.all()
        for post in posts:
            # If post has a file, include its URL
            print(post.id)
            writer.writerow([post.id, post.title, post.content, post.file.url if post.file else ''])

        return response

        


    

@api_view(["GET"])
def health(request):
    context={"status":"ok"}
    print(context)
    return Response(context)

@api_view(["GET"])
def readiness(request):
    context={"status":"ready"}
    print(context)
    return Response(context)


def get_user(request):
    
    print(request.user)
    