from django.urls import path
from rest_framework_simplejwt.views import (TokenObtainPairView,TokenRefreshView,)
from django.conf.urls.static import static
from django.conf import settings
from .views import BlogPostView,health,readiness,BlogPostViewById,BlogCommentViewById,get_user,AuditLogListView


urlpatterns = [
    
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('posts/', BlogPostView.as_view(), name='blog_post'),
    path('posts/<int:id>/', BlogPostViewById.as_view(), name='blog_post_id'),
    path('posts/<int:id>/comments/', BlogCommentViewById.as_view(), name='blog_comment_id'),
    path('audit-logs/', AuditLogListView.as_view()),
    path('health/',health,name='health'),
    path('readiness/',readiness,name='readiness'),
    path('get_user/',get_user,name='get_user')
    
]
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


#python -m http.server 5500   // it's use for normal html runsever