from rest_framework import serializers

from .models import *


class BlogPost_serializer(serializers.ModelSerializer):

    class Meta:
        model = Post_1
        fields = '__all__'

class BlogComment_serializer(serializers.ModelSerializer):

    username = serializers.CharField(source='author.username', read_only=True)

    class Meta:
        model = Comment_1
        fields = fields = ['id', 'post', 'username', 'content','created_at']

    


